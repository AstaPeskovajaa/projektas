<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="A layout example with a side menu that hides on mobile, just like the Pure website.">
  <title>Responsive Side Menu &ndash; Layout Examples &ndash; Pure</title>
  <link rel="stylesheet" type="text/css" href="reset.css">

  <link rel="stylesheet" href="https://unpkg.com/purecss@1.0.0/build/pure-min.css" integrity="sha384-" crossorigin="anonymous">



  <!--[if lte IE 8]>
            <link rel="stylesheet" href="css/layouts/side-menu-old-ie.css">
        <![endif]-->
  <!--[if gt IE 8]><!-->
  <link rel="stylesheet" href="css/layouts/side-menu.css">
  <!--<![endif]-->
</head>

<body>

  <div class="pure-menu pure-menu-horizontal">
    <a>MINIDEMINI</a>
    <ul class="pure-menu-list">
      <li class="pure-menu-item"><a href="index.php" class="pure-menu-link">Pagrindinis</a></li>
      <li class="pure-menu-item"><a href="galerija.php" class="pure-menu-link">Galerija</a></li>
      <li class="pure-menu-item"><a href="forma/public/kontaktai.php" class="pure-menu-link">Kontaktai</a></li>
    </ul>
  </div>


  <div id="main">
    <div class="header">
      <h1>
        <div class="pure-u-1-4">
          <img class="pure-img-responsive" src="foto/logo.jpg" alt="logo">
        </div>
      </h1>
      <h2>Jūsų nuostabiausiai šventei</h2>
    </div>

    <div class="content">
      <h2 class="content-subhead">Apie mane</h2>
      <p>
        Esu floristė - švenčių dekoratorė. Savo puslapyje dalinuosi savo darbų fotografijomis. Šiuo metu priimu užsakymus mini dekoro projektams,mielai apipavidalinsiu jūsų jaukias, nedideles šventes, pagaminsiu jums puokštes, kvietimus, stalo
        korteles ir kt.
      </p>
      <h2 class="content-subhead">Paslaugos</h2>
      <p>
        Floristika (gyvos gėlės, gėlių puokštės/kompozicijos, bažnyčios puošimas, salės dekoravimas ir kt.)<br>
        Stalo kortelių, kvietimų ar kitos šventinės atributikos maketavimas ir gamyba.<br>
        Taip pat Jūsų patogumui teikiame fotografo paslaugas.<br>
        Viskas Jūsų nuostabiai šventei...
      </p>

      <div class="pure-g">
        <div class="pure-u-1-4">
          <img class="pure-img-responsive" src="foto/4.jpg" alt="puokste1">
        </div>
        <div class="pure-u-1-4">
          <img class="pure-img-responsive" src="foto/5.jpg" alt="rozes">
        </div>
        <div class="pure-u-1-4">
          <img class="pure-img-responsive" src="foto/10.jpg" alt="puokste">
        </div>
        <div class="pure-u-1-4">
          <img class="pure-img-responsive" src="foto/3.jpg" alt="staloDekoras">
        </div>
      </div>

      <h2 class="content-subhead">Dar šis tas...</h2>
      <p>
        Specializuojuosi ties mažomis šventėmis ir nedideliais dekoro projektais. Padėsiu Jums pagal Jūsų numatytą biudžetą pasirinkti tinkamas gėles, sukurti kompozicijas iš jų, sumaketuosiu ir atspausdinsiu kvietimus, stalo korteles ir panašius šventinius gaminius (arba tiesiog paruošiu jums kompiuterinį variantą)
      </p>
    </div>
  </div>
  </div>




  <script src="js/ui.js"></script>

</body>


</html>
