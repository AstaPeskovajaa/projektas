  <div style="margin:0 auto;width:75%;text-align:center">
    <form class="pure-form" >
      <fieldset class="pure-group">
        <input style="margin:0 auto;width:75%;text-align:center" type="text" class="pure-input-1-2" placeholder="Vardas">
        <input style="margin:0 auto;width:75%;text-align:center" type="email" class="pure-input-1-2" placeholder="El.Paštas">
        <textarea style="margin:0 auto;width:75%;text-align:center" class="pure-input-1-2" placeholder="Palikite savo žinutę"></textarea>
        <button name="submit" style="background-color:#f0c2b7;" type="submit" class="pure-button pure-input-1-2 pure-button-primary">Siųsti</button>
      </fieldset>


    </form>


  </div>







<
