
<div class="header">
  <h1>
    <div class="pure-u-1-4">
      <img class="pure-img-responsive" src="../app/images/logo.jpg" alt="logo">
    </div>
  </h1>
  <h2>Jūsų nuostabiausiai šventei</h2>
</div>



<!-- <header>
    <div class="container">
        <img src="../app/images/logo.jpg" alt="logo">
    </div>
</header> -->
