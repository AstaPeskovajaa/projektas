<footer class="row">
  <section class="col-lg-6 col-md-6 col-sm-12">
    <div style="margin:0 auto;width:75%;text-align:center" class="box">
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2298.0863295105296!2d25.35714191546542!3d54.83116828031688!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46dd9bb66b58b825%3A0xe05005ac3d2e8380!2zQnJhxaFracWzIGcuLCBTa2lyZ2nFoWvEl3MgMTUxNjY!5e0!3m2!1slt!2slt!4v1542646992509"
        width="500" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
  </section>
  <section class="col-lg-6 col-md-6 col-sm-12">
    <div class="box">
      <address class="">
        <h2>Braškių g.11,Vilniaus raj.<br>
          +370 60564097</h2>

      </address>
    </div>
  </section>
</footer>
